package com.example.tuitionfinder;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
