package com.example.tuitionfinder;

public class profileImage {
    String profileImage;

    public profileImage() {
    }

    public profileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }
}
